#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

#include "clsPerson.h"
#include "clsString.h"
#include "clsDate.h"
#include "clsUtil.h"
#include "clsDataAccess.h"

#include "stLoginRegisterRecord.h"
#include "FilesPathsNames.h"

class clsUser : public clsPerson , protected clsDataAccess
{
public:
	enum enMode { EmptyMode = 0, UpdateMode = 1, AddNewMode = 2 };

private:

	
	string _UserName;
	string _Password;
	int _Permissions;

	bool _MarkedForDelete = false;


	enMode _Mode;

	
	string _PrepareLogInRecord(string Seperator = "#//#")
	{
		string LoginRecord = "";
		LoginRecord += clsDate::GetSystemDateTimeByString() + Seperator;
		LoginRecord += user_name + Seperator;
		LoginRecord += clsUtil::EncryptKey(password) + Seperator;
		LoginRecord += to_string(permissions);

		return LoginRecord;
	}
	


	static stLoginRegisterRecord _ConvertLoginRegisterLineToRecord(string LoginRegisterLine)
	{

		vector <string> LoginRegisterRecord = clsString::Split(LoginRegisterLine, "#//#");
		stLoginRegisterRecord LoginRegisterUser;

		LoginRegisterUser.Date_Time = LoginRegisterRecord.at(0);
		LoginRegisterUser.UserName = LoginRegisterRecord.at(1);
		LoginRegisterUser.Password = clsUtil::DecryptKey(LoginRegisterRecord.at(2) ,3);
		LoginRegisterUser.Permissions = stoi(LoginRegisterRecord.at(3));

		return LoginRegisterUser;
	}



	void _Add()
	{
		_AddDataLineToFile(_ConvertUserObjectToLine(*this) , UserFilePathName);
	}

	void _Update()
	{
		vector <clsUser> vUsers = _LoadDataFromFile(UserFilePathName);

		for (clsUser& S : vUsers)
		{
			if (S.user_name == UserName())
			{
				S = *this;
			}
		}
		
		_SaveDataToFile(vUsers , UserFilePathName);

	}

	

public :
	
	

	enum enPermissions {eAll = -1 , pListClients = 1, pAddNewClient = 2 , pDeleteClient = 4 ,
	pUpdateClient = 8 , pFindClient = 16 , pTransactions = 32 , pMangeUser = 64 , pLoginRegister = 128 };

	clsUser(enMode Mode, string FirstName, string LastName, string Email, string Phone
		, string UserName, string Password, int Permissions)

		: clsPerson(FirstName, LastName, Email, Phone)
	{
		_Mode = Mode;
		_UserName = UserName;
		_Password = Password;
		_Permissions = Permissions;
	}



	void SetUserName(string UserName)
	{
		_UserName = UserName;
	}

	string UserName()
	{
		return _UserName;
	}

	__declspec(property(get = UserName, put = SetUserName)) string user_name;


	void SetPassword(string Password)
	{
		_Password = Password;
	}

	string Password()
	{
		return _Password;
	}

	__declspec(property(get = Password, put = SetPassword)) string password;


	void SetPermissions(int Permissions)
	{
		_Permissions = Permissions;
	}

	int Permissions()
	{
		return _Permissions;
	}

	__declspec(property(get = Permissions, put = SetPermissions)) int permissions;


	bool GetMarkedDelete()
	{
		return _MarkedForDelete;
	}

	static clsUser Find(string UserName)
	{
		vector <clsUser> vUsers = _LoadDataFromFile(UserFilePathName);

		for (clsUser& S : vUsers)
		{
			if (S.user_name == UserName)
			{
				return S;
			}
		}

		return GetEmptyModeObject();
	}

	static clsUser Find(string UserName, string Password)
	{
		vector <clsUser> vUsers = _LoadDataFromFile(UserFilePathName);

		for (clsUser& S : vUsers)
		{
			if (S.user_name == UserName && S.password == Password)
			{
				return S;
			}
		}

		return GetEmptyModeObject();
	}

	bool IsEmpty()
	{
		return (_Mode == enMode::EmptyMode);
	}

	static bool IsUserExits(string UserName)
	{
		clsUser User = Find(UserName);
		return (!User.IsEmpty());
	}

	static clsUser GetAddNewModeObject(string UserName)
	{
		return clsUser(enMode::AddNewMode , "" , "" , "" , "" , UserName , "" , 0);
	}

	static clsUser GetEmptyModeObject()
	{
		return clsUser(enMode::EmptyMode, "", "", "", "", "", "", 0);
	}

	bool Delete()
	{
		vector <clsUser> vUsers = _LoadDataFromFile(UserFilePathName);

		for (clsUser& S : vUsers)
		{
			if (S.user_name == UserName())
			{
				S._MarkedForDelete = true;
				_SaveDataToFile(vUsers , UserFilePathName);
				*this = GetEmptyModeObject();
				return true;
			}
		}

		return false;
	}


	static vector <clsUser> GetListUsers()
	{
		return _LoadDataFromFile(UserFilePathName);
	}

	enum enSaveResult { svFaildSave = 0 , svSuccessded = 1 , svFaildEmptyObject = 2 , svFaildExitsObject = 3 };

	enSaveResult Save()
	{
		switch (_Mode)
		{
		case enMode::EmptyMode :
		{
			return enSaveResult::svFaildEmptyObject;
		}

		case enMode::UpdateMode :
		{
			_Update();
			return enSaveResult::svSuccessded;
		}

		case enMode::AddNewMode :
		{
			if (IsUserExits(user_name))
			{
				return enSaveResult::svFaildExitsObject;
			}

			_Add();
			_Mode = enMode::UpdateMode;
			return enSaveResult::svSuccessded;
		}
		}

		
	}

	bool CheckAccessPermissons(enPermissions Permission)
	{
		if (Permission == enPermissions::eAll)
		{
			return true;
		}

		if ((Permission & this->permissions) == Permission)
		{
			return true;
		}

		return false;
	}

	void RegisterLogIn()
	{

		string stDataLine = _PrepareLogInRecord();

		fstream MyFile;
		MyFile.open("LoginRegister.txt", ios::out | ios::app);

		if (MyFile.is_open())
		{

			MyFile << stDataLine << endl;

			MyFile.close();
		}

	}

	static vector <stLoginRegisterRecord> GetListLoginRegisterRecord()
	{
		vector <stLoginRegisterRecord> vLoginRegisterRecord;
		vector <string> Data;

		fstream MyFile;
		MyFile.open("LoginRegister.txt", ios::in);

		if (MyFile.is_open())
		{
			stLoginRegisterRecord User;
			string Line;

			while (getline(MyFile, Line))
			{
				User = _ConvertLoginRegisterLineToRecord(Line);
				vLoginRegisterRecord.push_back(User);
			}

			MyFile.close();
		}

		return vLoginRegisterRecord;
	}
};

