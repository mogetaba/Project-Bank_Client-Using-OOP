#pragma once

#include <iostream>
using namespace std;

#include "clsBankClient.h"
#include "clsInputValidate.h"
#include "clsScreen.h"

class clsWithdrawScreen : protected clsScreen
{
private :

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}

	static string _ReadAccountNumber()
	{
		return clsInputValidate::ReadString();
	}

public :

	static void ShowWithdrawScreen()
	{
		_DrawScreenHeader("\t  Withdraw Screen");

		cout << "Please Enter Account Number : ";
		string AccountNumber = _ReadAccountNumber();

		while (!clsBankClient::IsClientExits(AccountNumber))
		{
			cout << "Client with [" << AccountNumber << "] does not founs , please enter another account number : ";
			AccountNumber = _ReadAccountNumber();
		}

		clsBankClient Client = clsBankClient::Find(AccountNumber);
		_PrintClient(Client);

		cout << "\nEnter Amount to Withdraw : ";
		int Amount = clsInputValidate::ReadIntNumber();

		cout << "Are You sure want this transactions ? [y/n]";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			if (Client.Withdraw(Amount))
			{
				cout << "\nAmount Withdraw done Successfully :-) \n";
				cout << "\nAccount Balance Now : " << Client.Balance << endl;
			}
			else
			{
				cout << "\nCannot Withdraw , Insuffencient Balance ! \n";
				cout << "Amount Withdarw : " << Amount << endl;
				cout << "Account Balance : " << Client.Balance << endl;

			}
		}
		else
		{
			cout << "Operation is Cancelled \n";
		}
	}

};

