#pragma once

#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

#include "clsScreen.h"
#include "clsBankClient.h"
#include "clsInputValidate.h"



class clsTransferLogScreen : protected clsScreen
{
private:

	static void _PrintLoginRegisterRecordLine(clsBankClient::stTransferRegisteredRecord TransferRecord)
	{
		cout << "\n\t\t\t";

		cout << "| " << setw(24) << left << TransferRecord.DateTime;
		cout << "| " << setw(7) << left << TransferRecord.SourceAccountNumber;
		cout << "| " << setw(7) << left << TransferRecord.DestintionAccountNumber;
		cout << "| " << setw(10) << left << TransferRecord.Amount;
		cout << "| " << setw(12) << left << TransferRecord.srcBalanceAfter;
		cout << "| " << setw(12) << left << TransferRecord.destBalanceAfter;
		cout << "| " << setw(10) << left << TransferRecord.UserName;
		cout << "|";
	}


public:

	static void ShowTransferLogScreen()
	{
		vector <clsBankClient::stTransferRegisteredRecord> vTransferLogRecords = clsBankClient::GetListTransferLogRecord();

		string Title = "\t  Transfer Log Screen";
		string SubTitle = "Transfer Record [" + to_string(vTransferLogRecords.size()) + "](s).";


		_DrawScreenHeader(Title , SubTitle);

		cout << "\n\t\t\t____________________________________________________________________________";
		cout << "___________________________________________________________________________\n";

		cout << "\t\t\t";
		cout << "|" << setw(24) << left << " Data/Time";
		cout << "|" << setw(7) << left << " s.Acct";
		cout << "|" << setw(7) << left << " d.Acct";
		cout << "|" << setw(10) << left << " Amount";
		cout << "|" << setw(12) << left << " s.Balance";
		cout << "|" << setw(12) << left << " d.Balance";
		cout << "|" << setw(10) << left << " User Name";
		cout << "|";

		cout << "\n\t\t\t____________________________________________________________________________";
		cout << "___________________________________________________________________________\n";

		if (vTransferLogRecords.size() == 0)
		{
			cout << "No Login Avaliable in the system...\n";
		}
		else
		{
			for (clsBankClient::stTransferRegisteredRecord& TransferRecord : vTransferLogRecords)
			{
				_PrintLoginRegisterRecordLine(TransferRecord);
			}
		}

		cout << "\n\t\t\t____________________________________________________________________________";
		cout << "___________________________________________________________________________\n";
	}
};

