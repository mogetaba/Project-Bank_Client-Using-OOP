#include <iostream>
using namespace std;

#include "clsLoginScreen.h"
#include "clsMainScreen.h"

int main()
{
    while (true)
    {
        if (!clsLoginScreen::ShowLoginScreen())
        {
            break;
        }
    }

    

    return 0;
}
