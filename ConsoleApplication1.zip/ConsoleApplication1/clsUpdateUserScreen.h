#pragma once
#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"

class clsUpdateUserScreen : protected clsScreen
{
private :

	static void _ReadInfoUser(clsUser& User)
	{
		cout << "Enter First Name : ";
		User.FirstName = clsInputValidate::ReadString();

		cout << "Enter Last Name : ";
		User.LastName = clsInputValidate::ReadString();

		cout << "Enter Email : ";
		User.Email = clsInputValidate::ReadString();

		cout << "Enter Phone Number : ";
		User.Phone = clsInputValidate::ReadString();

		cout << "Enter Password : ";
		User.password = clsInputValidate::ReadString();

		cout << "Enter Permissions : ";
		User.permissions = _ReadPermissionsUser();
	}

	static int _ReadPermissionsUser()
	{
		cout << "Do you want give full access ? [y/n]";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			return -1;
		}

		int Permissions = 0;
		cout << "\nDo you want give access to : \n";

		cout << "Do you want give List Clients access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pListClients;
		}

		cout << "\nDo you want give Add New Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pAddNewClient;
		}

		cout << "\nDo you want give Delete Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pDeleteClient;
		}

		cout << "\nDo you want give Update Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pUpdateClient;
		}

		cout << "\nDo you want give Find Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pFindClient;
		}

		cout << "\nDo you want give Transactions access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pTransactions;
		}

		cout << "\nDo you want give Mange User access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pMangeUser;
		}

		return Permissions;
	}

	static void _PrintUser(clsUser User)
	{
		cout << "\nUser Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << User.FirstName;
		cout << "\nLastName    : " << User.LastName;
		cout << "\nFull Name   : " << User.getFullName();
		cout << "\nEmail       : " << User.Email;
		cout << "\nPhone       : " << User.Phone;
		cout << "\nUser Name   : " << User.user_name;
		cout << "\nPassword    : " << User.password;
		cout << "\nPermissions : " << User.permissions;
		cout << "\n___________________\n";

	}

public :

	static void ShowUpdateUserScreen()
	{
		_DrawScreenHeader("\t  Update User Screen");
		string UserName = "";

		cout << "Please Enter User Name : ";
		UserName = clsInputValidate::ReadString();

		while (!clsUser::IsUserExits(UserName))
		{
			cout << "This User Name is not found , enter another User Name : ";
			UserName = clsInputValidate::ReadString();
		}

		clsUser User = clsUser::Find(UserName);
		_PrintUser(User);

		cout << "\nAre You sure do you want update info User ? [y/n]";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			cout << "\nUpdate Info :";
			cout << "\n__________________";
			cout << "\n";

			_ReadInfoUser(User);

			clsUser::enSaveResult SaveResult; 
			SaveResult = User.Save();

			switch (SaveResult)
			{
			case clsUser::enSaveResult::svSuccessded: 
			{
				cout << "\nUpdate Info User done successfully :-)";
				cout << "\n";

				_PrintUser(User);
				break;
			}

			case clsUser::enSaveResult::svFaildEmptyObject :
			{
				cout << "\nError Save Updated Info User :-(";
				cout << "\n";
				break;
			}
			}

		}

	}

};

