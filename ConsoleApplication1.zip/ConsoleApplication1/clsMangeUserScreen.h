#pragma once

#include <iostream>
#include <iomanip>
using namespace std;

#include "clsScreen.h"
#include "clsInputValidate.h"

#include "clsListUsersScreen.h"
#include "clsAddNewUserScreen.h"
#include "clsDeleteUserScreen.h"
#include "clsUpdateUserScreen.h"
#include "clsFindUserScreen.h"

#include "clsUser.h"

class clsMangeUserScreen : protected clsScreen
{
private :

	enum enMangeUserMenueOptions { eListUsers = 1 , eAddUser = 2 , eDeleteUser = 3 ,
	eUpdateUser = 4 , eFindUser = 5 , eMainMenue = 6};
	
	
	static short _ReadUserOption()
	{
		cout << "\t\t\tChoose what do you want ? [ 1 to 6 ] ? ";
		return clsInputValidate::ReadShortNumberBetween(1, 6 , "Error , enter num from 1 to 6 : ");
	}

	static void _ShowListUsersScreen()
	{
		clsListUsersScreen::ShowListUsersScreen();
	}

	static void _ShowAddUserScreen()
	{
		clsAddNewUserScreen::ShowAddNewUserScreen();
	}

	static void _ShowDeleteUserScreen()
	{
		clsDeleteUserScreen::ShowDeleteUserScreen();
	}

	static void _ShowUpdateUserScreen()
	{
		clsUpdateUserScreen::ShowUpdateUserScreen();
	}

	static void _ShowFindUserScreen()
	{
		clsFindUserScreen::ShowFindUserScreen();
	}
 

	static void _GoBackToMangeUserMenue()
	{
		cout << "\t\t\tPress any key to Mange User Menue...";
		system("pause>0");

		ShowMangeUserScreen();

	}

	static void _PerformMangeUserMenueOption( enMangeUserMenueOptions Option )
	{
		switch (Option)
		{
		case enMangeUserMenueOptions::eListUsers :
		{
			system("cls");
			_ShowListUsersScreen();
			_GoBackToMangeUserMenue();
			break ;
		}

		case enMangeUserMenueOptions::eAddUser :
		{
			system("cls") ;
			_ShowAddUserScreen();
			_GoBackToMangeUserMenue();
			break;
		}

		case enMangeUserMenueOptions::eDeleteUser:
		{
			system("cls");
			_ShowDeleteUserScreen();
			_GoBackToMangeUserMenue();
			break;
		}

		case enMangeUserMenueOptions::eUpdateUser:
		{
			system("cls");
			_ShowUpdateUserScreen();
			_GoBackToMangeUserMenue();
			break;
		}

		case enMangeUserMenueOptions::eFindUser:
		{
			system("cls");
			_ShowFindUserScreen();
			_GoBackToMangeUserMenue();
			break;
		}

		case enMangeUserMenueOptions::eMainMenue :
		{

		}
		}
	}


public :
	
	static void ShowMangeUserScreen()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pMangeUser))
		{
			return;
		}


		system("cls");
		_DrawScreenHeader("\t  Mange User");

		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t\t  Manage Users Menue\n";
		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t[1] List Users.\n";
		cout << setw(37) << left << "" << "\t[2] Add New User.\n";
		cout << setw(37) << left << "" << "\t[3] Delete User.\n";
		cout << setw(37) << left << "" << "\t[4] Update User.\n";
		cout << setw(37) << left << "" << "\t[5] Find User.\n";
		cout << setw(37) << left << "" << "\t[6] Main Menue.\n";
		cout << setw(37) << left << "" << "===========================================\n";

		_PerformMangeUserMenueOption((enMangeUserMenueOptions)_ReadUserOption());
	}

};

