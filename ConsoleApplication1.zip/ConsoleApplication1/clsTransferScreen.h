#pragma once

#include <iostream>
using namespace std;

#include "clsBankClient.h"
#include "clsInputValidate.h"
#include "clsScreen.h"

class clsTransferScreen : protected clsScreen
{
private:

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}

	static string _ReadAccountNumber()
	{
		cout << "Enter Account Number : ";
		string AccountNumber = clsInputValidate::ReadString();

		while (!clsBankClient::IsClientExits(AccountNumber))
		{
			cout << "This Account Number not found , please enter another Account Number : ";
			AccountNumber = clsInputValidate::ReadString();
		}

		return AccountNumber;
	}

	static float _ReadAmount(clsBankClient SourceClient)
	{
		cout << "Enter Amount ? ";
		float Amount = clsInputValidate::ReadDblNumber();

		while (Amount > SourceClient.Balance)
		{
			cout << "That Amount is Excesdes , please Enter Amount ? ";
			Amount = clsInputValidate::ReadDblNumber();
		}

		return Amount;
	}

public:
	
	static void ShowTransferScreen()
	{
		_DrawScreenHeader("\t  Transfer Screen");

		clsBankClient SourceClient = clsBankClient::Find(_ReadAccountNumber());
		_PrintClient(SourceClient);

		clsBankClient DestintialClient = clsBankClient::Find(_ReadAccountNumber());
		_PrintClient(DestintialClient);

		float Amount = _ReadAmount(SourceClient);
	
		cout << "\nAre You Sure From This Operation ? [y/n] ";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{

			if (SourceClient.Transfer(DestintialClient, Amount , CurrentUser.user_name))
			{
				cout << "\nTransfer Amount Done Successfully !\n";

				_PrintClient(SourceClient);
				cout << "\n\n";
				_PrintClient(DestintialClient);

			}
			else
			{
				cout << "\nError In Transfer , check Account Number or Amount Later...\n";
			}
		}
		else
		{
			cout << "\nThe Operation Canceld.\n";
		}

	}
};

