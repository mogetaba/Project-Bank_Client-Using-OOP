#pragma once

#include <iostream>
using namespace std;

#include "clsBankClient.h"
#include "clsInputValidate.h"
#include "clsScreen.h"

#include "clsUser.h"

class clsUpdateClientScreen : protected clsScreen
{
private:

	static void _ReadInfoClient(clsBankClient& NewClient)
	{
		cout << "Enter First Name  : ";
		NewClient.FirstName = clsInputValidate::ReadString();

		cout << "Enter Last Name : ";
		NewClient.LastName = clsInputValidate::ReadString();

		cout << "Enter Email : ";
		NewClient.Email = clsInputValidate::ReadString();

		cout << "Enter Phone : ";
		NewClient.Phone = clsInputValidate::ReadString();

		cout << "Enter Pin Code : ";
		NewClient.PinCode = clsInputValidate::ReadString();

		cout << "Enter Balance : ";
		NewClient.Balance = clsInputValidate::ReadIntNumber();
	}

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}


public:

	static void ShowUpdateClientScreen()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pUpdateClient))
		{
			return;
		}

		_DrawScreenHeader("\t   Update Client Screen");

		cout << "Enter Account Number : ";
		string AccountNumber = clsInputValidate::ReadString();

		while (!(clsBankClient::IsClientExits(AccountNumber)))
		{
			cout << "This Account number is not found , enter another account number : ";
			AccountNumber = clsInputValidate::ReadString();
		}


		clsBankClient Client = clsBankClient::Find(AccountNumber);
		_PrintClient(Client);

		cout << "\n\nDo you want deleted this client ? [y/n]";
		char answer = 'n';
		cin >> answer;


		if (answer == 'y' || answer == 'Y')
		{
			cout << "\n\nUpdate Info : \n";
			cout << "__________________________________\n";
			_ReadInfoClient(Client);
			cout << "__________________________________\n";
		}

		clsBankClient::enSaveResult SaveResult = Client.Save();

		switch (SaveResult)
		{
		case clsBankClient::enSaveResult::svSuccessded:
		{
			cout << "Updated Client done successfully :-> \n";
			_PrintClient(Client);
			break;
		}

		case clsBankClient::enSaveResult::svFaildEmptyClient:
		{
			cout << "not Update client :-< \n";
			break;
		}
		}

	}

};

