#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

#include "clsScreen.h"
#include "clsString.h"
#include "clsUser.h"
#include "stLoginRegisterRecord.h"

class clsRegisterLoginScreen : protected clsScreen
{
private :

	static void _PrintLoginRegisterRecordLine( stLoginRegisterRecord User )
	{
		cout << "\n\t\t\t";

		cout << "| " << setw(30) << left << User.Date_Time;
		cout << "| " << setw(24) << left << User.UserName;
		cout << "| " << setw(10) << left << User.Password;
		cout << "| " << setw(12) << left << User.Permissions;
		cout << "|";
	}

public :

	static void ShowRegisterLoginScreen()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pLoginRegister))
		{
			return;
		}

		vector <stLoginRegisterRecord> vUsers = clsUser::GetListLoginRegisterRecord();

		string Title = "Register Login Screen";
		string SubTitle = "Users [" + to_string(vUsers.size()) + "] Record(s).";
		
		_DrawScreenHeader(Title , SubTitle);

		cout << "\n\t\t\t______________________________________________________";
		cout << "____________________________\n";

		cout << "\t\t\t";
		cout << "|" << setw(30) << left << " Data/Time";
		cout << "|" << setw(24) << left << " User Name";
		cout << "|" << setw(10) << left << " Password";
		cout << "|" << setw(12) << left << " Permissions";
		cout << "|";

		cout << "\n\t\t\t________________________________________________";
		cout << "__________________________________\n";

		if (vUsers.size() == 0)
		{
			cout << "No Login Avaliable in the system...\n";
		}
		else
		{
			for (stLoginRegisterRecord& User : vUsers)
			{
				_PrintLoginRegisterRecordLine(User);
			}
		}

		cout << "\n\t\t\t________________________________________________";
		cout << "__________________________________\n";
	}

};

