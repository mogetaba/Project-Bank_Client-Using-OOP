#pragma once

#include <iostream>
using namespace std;

#include "clsInputValidate.h"

#include "clsScreen.h"
#include "clsBankClient.h"

#include "clsUser.h"

class clsDeleteClientScreen : protected clsScreen
{
private:

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}


public:

	static void ShowDeleteClientScreen()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pDeleteClient))
		{
			return;
		}

		_DrawScreenHeader("\t   Delete Client Screen");

		cout << "Enter Account Number : ";
		string AccountNumber = clsInputValidate::ReadString();

		while (!(clsBankClient::IsClientExits(AccountNumber)))
		{
			cout << "This Account number is not found , enter another account number : ";
			AccountNumber = clsInputValidate::ReadString();
		}


		clsBankClient Client = clsBankClient::Find(AccountNumber);
		_PrintClient(Client);

		cout << "\n\nDo you want deleted this client ? [y/n]";
		char answer = 'n';
		cin >> answer;

		if ( answer == 'y' || answer == 'Y')
		{
			if (Client.Delete())
			{
				cout << "Deleted Account Client done successfully :->\n\n " ;
				_PrintClient(Client);
			}
			else
			{
				cout << "was not delted client :-< \n";
			}
				 
		}

	}

};

