#pragma once

#include <iostream>
#include <iomanip>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"

class clsListUsersScreen : protected clsScreen
{
private :

    static void _PrintClientRecordLine(clsUser User)
    {

        cout << setw(8) << left << "" << "| " << setw(15) << left << User.user_name;
        cout << "| " << setw(20) << left << User.FirstName;
        cout << "| " << setw(12) << left << User.LastName;
        cout << "| " << setw(20) << left << User.Email;
        cout << "| " << setw(10) << left << User.password;
        cout << "| " << setw(12) << left << User.permissions;

    }

public :

    static void ShowListUsersScreen()
    {
        vector <clsUser> vUsers = clsUser::GetListUsers();

        string Title = "\t    List Users Screen";
        string SubTitle = "\t\t ( " + to_string(vUsers.size()) + " ) Users(s).";
        _DrawScreenHeader(Title , SubTitle);


        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "______________________________________________\n" << endl;

        cout << setw(8) << left << "" << "| " << left << setw(12) << "UserName";
        cout << "| " << left << setw(25) << "Full Name";
        cout << "| " << left << setw(12) << "Phone";
        cout << "| " << left << setw(20) << "Email";
        cout << "| " << left << setw(10) << "Password";
        cout << "| " << left << setw(12) << "Permissions";
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "______________________________________________\n" << endl;

        if (vUsers.size() == 0)
            cout << "\t\t\t\tNo Users Available In the System!";
        else

            for (clsUser User : vUsers)
            {

                _PrintClientRecordLine(User);
                cout << endl;
            }

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "______________________________________________\n" << endl;

    }

};

