#pragma once

#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsBankClient.h"
#include "clsInputValidate.h"

#include "clsUser.h"

class clsFindClientScreen : protected clsScreen
{
private : 

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}

public :

	static void ShowFindClientScreen()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pFindClient))
		{
			return;
		}

		_DrawScreenHeader("\t  Find Client Screen");

		cout << "Enter Acc. Number : ";
		string AccountNumber = clsInputValidate::ReadString() ;

		while (!clsBankClient::IsClientExits(AccountNumber))
		{
			cout << "Account Number is not found , enter another one : ";
			AccountNumber = clsInputValidate::ReadString();
		}

		clsBankClient Client = clsBankClient::Find(AccountNumber);

		if (!Client.IsEmpty())
		{
			cout << "\nAccount Number is found :-) \n";
		}
		else
		{
			cout << "Account Number is not found :-( \n";
		}

		_PrintClient(Client);
	}

};

