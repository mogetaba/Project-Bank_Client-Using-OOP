#pragma once

#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"

class clsFindUserScreen : protected clsScreen
{

private :

	static void _PrintUser(clsUser& User)
	{
		cout << "\nUser Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << User.FirstName;
		cout << "\nLastName    : " << User.LastName;
		cout << "\nFull Name   : " << User.getFullName();
		cout << "\nEmail       : " << User.Email;
		cout << "\nPhone       : " << User.Phone;
		cout << "\nUser Name   : " << User.user_name;
		cout << "\nPassword    : " << User.password;
		cout << "\nPermissions : " << User.permissions;
		cout << "\n___________________\n";
	}

public :


	static void ShowFindUserScreen()
	{
		_DrawScreenHeader("\t  Find User Screen");

		cout << "Please Enter User Name : ";
		string UserName = clsInputValidate::ReadString();

		while (!clsUser::IsUserExits(UserName))
		{
			cout << "User Name is not found , please enter another User Name : ";
			UserName = clsInputValidate::ReadString();
		}

		clsUser User = clsUser::Find(UserName);

		cout << "\nThe User is found :-) \n";
		_PrintUser(User);

	}


};

