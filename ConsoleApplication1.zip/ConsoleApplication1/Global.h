#pragma once

#include <iostream>
#include "clsUser.h"

extern clsUser CurrentUser = clsUser::Find("", "");
short EncryptKey = 3;