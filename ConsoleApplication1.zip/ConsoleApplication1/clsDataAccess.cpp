#include "clsDataAccess.h"
#include <iostream>
#include <vector>
using namespace std;

#include "clsDate.h"
#include "clsUser.h"
#include "clsBankClient.h"
#include "clsUtil.h"

string clsDataAccess::_ConvertUserObjectToLine(clsUser User ,string Sperator)
{
	string Line;

	Line += User.FirstName + Sperator;
	Line += User.LastName + Sperator;
	Line += User.Email + Sperator;
	Line += User.Phone + Sperator;
	Line += User.user_name + Sperator;
	Line += clsUtil::EncryptKey(User.password) + Sperator;
	Line += to_string(User.permissions);

	return Line;
}

clsUser clsDataAccess::_ConvertLineToUserObject(string Line)
{
	vector <string> vUser = clsString::Split(Line, "#//#");

	if (vUser.size() < 7)
		return clsUser(clsUser::enMode::EmptyMode, "", "", "", ""
			, "", "", 0);

	return clsUser(clsUser::enMode::UpdateMode, vUser[0], vUser[1], vUser[2]
		, vUser[3], vUser[4], clsUtil::DecryptKey(vUser[5]), stoi(vUser[6]));
}

vector <clsUser> clsDataAccess::_LoadDataFromFile(string FilePathName)
{
	vector <clsUser> vUsers;
	fstream MyFile;
	MyFile.open(FilePathName, ios::in);

	if (MyFile.is_open())
	{
		string Line;
		while (getline(MyFile, Line))
		{
			if(!Line.empty())
				vUsers.push_back(_ConvertLineToUserObject(Line));
			
		}

		MyFile.close();
	}

	return vUsers;
}


void clsDataAccess::_SaveDataToFile(vector <clsUser> vUsers , string FilePathName)
{
	fstream MyFile;
	MyFile.open(FilePathName, ios::out);

	if (MyFile.is_open())
	{
		for (clsUser& S : vUsers)
		{
			if (S.GetMarkedDelete() == false)
			{
				string Line = _ConvertUserObjectToLine(S);
				MyFile << Line << endl;
			}

		}

		MyFile.close();
	}
}


void clsDataAccess::_AddDataLineToFile(string stUser , string FilePathName)
{
	fstream MyFile;
	MyFile.open(FilePathName, ios::app);

	if (MyFile.is_open())
	{
		MyFile << stUser << endl;
		MyFile.close();
	}
}

vector <clsBankClient> clsDataAccess::_LoadDataFromFile(string FilePathName, bool isClientRecords)
{
	vector <clsBankClient> vClient;

	fstream MyFile;
	MyFile.open(FilePathName, ios::in);

	if (MyFile.is_open())
	{
		string Line;
		clsBankClient Client;

		while (getline(MyFile, Line))
		{
			if (!Line.empty())
			{
				Client = _ConvertLineToClientObject(Line);
				vClient.push_back(Client);
			}
		}

		MyFile.close();
	}

	return vClient;
}

void clsDataAccess::_SaveClientDataToFile(vector <clsBankClient> vClient, string FilePathName)
{
	fstream MyFile;
	MyFile.open(FilePathName, ios::out);

	if (MyFile.is_open())
	{

		string stClient;

		for (clsBankClient& C : vClient)
		{
			if (C.getMarkedForDeleted() == false)
			{
				stClient = _ConvertClientObjectToLine(C, "#//#");
				MyFile << stClient << endl;
			}
		}


		MyFile.close();
	}
}

void clsDataAccess::_AddClientDataToFile(string stDataLine, string FilePathName)
{
	fstream MyFile;
	MyFile.open(FilePathName, ios::out | ios::app);

	if (MyFile.is_open())
	{
		MyFile << stDataLine << endl;
		MyFile.close();
	}
}

clsBankClient clsDataAccess::_ConvertLineToClientObject(string Line , string Sperator)
{
	vector <string> vClient = clsString::Split(Line, Sperator);

	if(vClient.size() < 7)
		return clsBankClient(clsBankClient::enMode::EmptyMode, "", "", "", ""
			, "", "", 0);

	return clsBankClient(clsBankClient::enMode::UpdateMode, vClient[0], vClient[1], vClient[2]
		, vClient[3], vClient[4], vClient[5], stod(vClient[6]));
}

string clsDataAccess::_ConvertClientObjectToLine(clsBankClient Client, string Delim)
{
	string S1 = "";
	string Empty = "";

	if (Client.getMode() == clsBankClient::enMode::EmptyMode)
		return Empty;
	

	S1 += Client.getFirstName() + Delim;
	S1 += Client.getLastName() + Delim;
	S1 += Client.getEmail() + Delim;
	S1 += Client.getPhone() + Delim;
	S1 += Client.getAccountNumber() + Delim;
	S1 += Client.getPinCode() + Delim;
	S1 += to_string(Client.getBalance());


	return S1;
}