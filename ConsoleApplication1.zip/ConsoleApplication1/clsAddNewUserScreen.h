#pragma once

#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"

class clsAddNewUserScreen : protected clsScreen
{
private :

	static void _PrintUser(clsUser User)
	{
		cout << "\nUser Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << User.FirstName;
		cout << "\nLastName    : " << User.LastName;
		cout << "\nFull Name   : " << User.getFullName();
		cout << "\nEmail       : " << User.Email;
		cout << "\nPhone       : " << User.Phone;
		cout << "\nUser Name   : " << User.user_name;
		cout << "\nPassword    : " << User.password;
		cout << "\nPermissions : " << User.permissions;
		cout << "\n___________________\n";

	}

	static void _ReadInfoUser(clsUser& User)
	{
		cout << "Enter First Name : ";
		User.FirstName = clsInputValidate::ReadString();

		cout << "Enter Last Name : ";
		User.LastName = clsInputValidate::ReadString();

		cout << "Enter Email : ";
		User.Email = clsInputValidate::ReadString();

		cout << "Enter Phone Number : ";
		User.Phone = clsInputValidate::ReadString();

		cout << "Enter Password : ";
		User.password = clsInputValidate::ReadString();

		cout << "Enter Permissions : ";
		User.permissions = _ReadPermissionsUser();
	}

	static int _ReadPermissionsUser()
	{
		cout << "Do you want give full access ? [y/n]";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			return -1;
		}

		int Permissions = 0;
		cout << "\nDo you want give access to : \n";

		cout << "Do you want give List Clients access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pListClients;
		}

		cout << "\nDo you want give Add New Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pAddNewClient;
		}

		cout << "\nDo you want give Delete Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pDeleteClient;
		}

		cout << "\nDo you want give Update Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pUpdateClient;
		}

		cout << "\nDo you want give Find Client access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pFindClient;
		}

		cout << "\nDo you want give Transactions access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pTransactions;
		}

		cout << "\nDo you want give Mange User access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pMangeUser;
		}

		cout << "\nDo you want give Login Register User access ? [y/n]";
		Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			Permissions += clsUser::enPermissions::pLoginRegister;
		}

		return Permissions;
	}

public :

	static void ShowAddNewUserScreen()
	{
		_DrawScreenHeader("\t  Add New User Screen");

		cout << "Enter User Name to Add : ";
		string UserName = clsInputValidate::ReadString();

		while (clsUser::IsUserExits(UserName))
		{
			cout << "This User Name is found , pleae Enter another UserName : ";
			string UserName = clsInputValidate::ReadString();
		}

		clsUser NewUser = clsUser::GetAddNewModeObject(UserName);
		_ReadInfoUser(NewUser);

		clsUser::enSaveResult SaveResult;
		SaveResult = NewUser.Save();

		switch (SaveResult)
		{
		case clsUser::enSaveResult::svSuccessded :
		{
			cout << "User Added Successfully ! \n";
			_PrintUser(NewUser);
			break;
		}

		case clsUser::enSaveResult::svFaildEmptyObject :
		{
			cout << "User not added , because it is empty !";
			break;
		}

		case clsUser::enSaveResult::svFaildExitsObject :
		{
			cout << "User not added , because it is found !";
		}
		}
	}

};

