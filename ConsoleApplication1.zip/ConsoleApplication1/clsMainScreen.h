#pragma once

#include <iostream>
#include <iomanip>


#include "clsScreen.h"
#include "clsInputValidate.h"
#include "Global.h"
#include "clsUser.h"

#include "clsClientsListScreen.h"
#include "clsAddNewClientScreen.h"
#include "clsDeleteClientScreen.h"
#include "clsUpdateClientScreen.h"
#include "clsFindClientScreen.h"


#include "clsTransactionsScreen.h"
#include "clsMangeUserScreen.h"
#include "clsRegisterLoginScreen.h"

using namespace std;



class clsMainScreen :  protected clsScreen
{
private:

    enum enMainMenueOption { eListClient = 1 , eAddNewClient = 2 , eDeleteClient = 3 , eUpdateClient = 4 , eFindClient = 5 
    , eTransactios = 6 , eMangeUsers = 7 , eRegisterLogin = 8 , eExits = 9 };


    static short _ReadMainMenueOption()
    {
        cout << "\t\t\t\t\tChoose Option from main menue [1 To 9] ? ";
        return clsInputValidate::ReadShortNumberBetween(1, 9, "Invalid Number Between From 1 To 9 : ");
    }
    
    static void _GoToBackMainMenue()
    {
        cout << setw(37) << left << "\t\tPress Any Key To go back to main menue...\n";

        system("pause>0");
        ShowMainMenue();
    }

    static void _ShowAllClientScreen()
    {
        clsClientsList::ShowListClients();
    }

    static void _ShowAddNewClientScreen()
    {
        clsAddNewClientScreen::ShowAddNewClientScreen();
    }

    static void _ShowDeleteClientScreen()
    {
        clsDeleteClientScreen::ShowDeleteClientScreen();
    }


    static void _ShowUpdateClientScreen()
    {
        clsUpdateClientScreen::ShowUpdateClientScreen();
    }


    static void _ShowFindClientScreen()
    {

        clsFindClientScreen::ShowFindClientScreen();
    }

    static void _ShowTransactionsScreen()
    {
        clsTransactionsScreen::ShowTransactionsMenue();
    }

    static void _ShowMangeUsersScreen()
    {
        clsMangeUserScreen::ShowMangeUserScreen();
    }

    static void _ShowRegisterLoginScreen()
    {
        clsRegisterLoginScreen::ShowRegisterLoginScreen();
    }


    /*static void _ShowEndScreen()
    {
        cout << "\t\t\t==============================================";
        cout << "\n\t\t\tThank you , go to here later :-) \n";
        cout << "\a\a\a";
        cout << "\n\t\t\t==============================================";
    }*/

    static void _ShowLogoutScreen()
    {
        CurrentUser = clsUser::Find("", "");
    }

    static void _PerformMainMenueOption( enMainMenueOption Option )
    {
        switch (Option)
        {
        case enMainMenueOption::eListClient:
        {
            system("cls");
            _ShowAllClientScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eAddNewClient:
        {
            system("cls");
            _ShowAddNewClientScreen();
            _GoToBackMainMenue();
            break;
        }


        case enMainMenueOption::eDeleteClient:
        {
            system("cls");
            _ShowDeleteClientScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eUpdateClient:
        {
            system("cls");
            _ShowUpdateClientScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eFindClient:
        {
            system("cls");
            _ShowFindClientScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eTransactios:
        {
            system("cls");
            _ShowTransactionsScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eMangeUsers :
        {
            system("cls");
            _ShowMangeUsersScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eRegisterLogin:
        {
            system("cls");
            _ShowRegisterLoginScreen();
            _GoToBackMainMenue();
            break;
        }

        case enMainMenueOption::eExits:
        {
            system("cls") ;
            _ShowLogoutScreen();
        }

        }
    }

public:

	static void ShowMainMenue()
    {

            system("cls");
            _DrawScreenHeader("\t\tMain Screen");

            cout << setw(37) << left << "" << "===========================================\n";
            cout << setw(37) << left << "" << "\t\t\tMain Menue\n";
            cout << setw(37) << left << "" << "===========================================\n";
            cout << setw(37) << left << "" << "\t[1] Show Client List.\n";
            cout << setw(37) << left << "" << "\t[2] Add New Client.\n";
            cout << setw(37) << left << "" << "\t[3] Delete Client.\n";
            cout << setw(37) << left << "" << "\t[4] Update Client Info.\n";
            cout << setw(37) << left << "" << "\t[5] Find Client.\n";
            cout << setw(37) << left << "" << "\t[6] Transactions.\n";
            cout << setw(37) << left << "" << "\t[7] Manage Users.\n";
            cout << setw(37) << left << "" << "\t[8] Register Login.\n";
            cout << setw(37) << left << "" << "\t[9] Logout.\n";
            cout << setw(37) << left << "" << "===========================================\n";
       

            _PerformMainMenueOption(enMainMenueOption(_ReadMainMenueOption()));
	}

};

