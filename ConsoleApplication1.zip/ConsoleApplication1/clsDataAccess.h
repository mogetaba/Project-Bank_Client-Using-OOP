#pragma once
#include <iostream>
#include <vector>
using namespace std;

#include "stLoginRegisterRecord.h"

class clsUser;
class clsBankClient;

class clsDataAccess
{
protected:


	// clsUser

	static string _ConvertUserObjectToLine(clsUser User, string Sperator = "#//#");
	static clsUser _ConvertLineToUserObject(string Line);
	static stLoginRegisterRecord _ConvertLoginRegisterLineToRecord(string LoginRegisterLine);
	static vector <clsUser> _LoadDataFromFile(string FilePathName);
	static void _SaveDataToFile(vector <clsUser> vUsers, string FilePathName);
	static void _AddDataLineToFile(string stUser, string FilePathName);


	// clsbankClient

	static clsBankClient _ConvertLineToClientObject(string Line, string Spearator = "#//#");
	static string _ConvertClientObjectToLine(clsBankClient Client, string Delim = "#//#");
	static vector <clsBankClient> _LoadDataFromFile(string FilePathName , bool isClientRecords);
	static void _SaveClientDataToFile(vector <clsBankClient> vClient, string FilePathName);
	static void _AddClientDataToFile(string stDataLine, string FilePathName);
};

