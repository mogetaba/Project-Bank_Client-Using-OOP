#pragma once

#include <iostream>
#include <iomanip>
using namespace std;

#include "clsScreen.h"
#include "clsInputValidate.h"


#include "clsDepositScreen.h"
#include "clsWithdrawScreen.h"
#include "clsTotalBalancesScreen.h"
#include "clsTransferScreen.h"
#include "clsTransferLogScreen.h"

#include "clsUser.h"

class clsTransactionsScreen : protected clsScreen
{
private :

	enum enTransactionMenue { eShowDeposit = 1 , eShowWithdraw = 2 , eShowTotalBalances = 3 ,
	eShowTransfer = 4 , eShowTransferLog = 5 , eShowMainMenue = 6 };


	static short ReadChooseUser()
	{
		cout << "\t\t\tChoose what do you want ? [1 to 6] ";
		return clsInputValidate::ReadShortNumberBetween(1 , 6 , "Error , enter number from 1 to 6 ");
	}

	static void _ShowDepositScreen()
	{
		clsDepositScreen::ShowDepositScreen();
	}

	static void _ShowWithdrawScreen()
	{
		clsWithdrawScreen::ShowWithdrawScreen();
	}

	static void _ShowTransferScreen()
	{
		clsTransferScreen::ShowTransferScreen();
	}


	static void _ShowTotalBalancesScreen()
	{
		clsTotalBalancesScreen::ShowTotalBalancesScreen();
	}


	static void _ShowTransferLogScreen()
	{
		clsTransferLogScreen::ShowTransferLogScreen();
	}

	static void _PerformTransactiosMenue( enTransactionMenue TransactionOption )
	{
		switch (TransactionOption)
		{
		case enTransactionMenue::eShowDeposit :
		{
			system("cls");
			_ShowDepositScreen();
			_GoBackToTransationsMenue();
			break;
		}

		case enTransactionMenue::eShowWithdraw :
		{
			system("cls");
			_ShowWithdrawScreen();
			_GoBackToTransationsMenue();
			break;
		}

		case enTransactionMenue::eShowTotalBalances :
		{
			system("cls");
			_ShowTotalBalancesScreen();
			_GoBackToTransationsMenue();
			break;
		}

		case enTransactionMenue::eShowTransfer:
		{
			system("cls");
			_ShowTransferScreen();
			_GoBackToTransationsMenue();
			break;
		}

		case enTransactionMenue::eShowTransferLog:
		{
			system("cls");
			_ShowTransferLogScreen();
			_GoBackToTransationsMenue();
			break;
		}

		case enTransactionMenue::eShowMainMenue :
		{
			// Closed this Class Automaticklly After Choose the User Function "ShowMainMenue"
		}
		}
	}


	static void _GoBackToTransationsMenue()
	{
		cout << setw(37) << left << "\t\tPress Any Key To go back to Transations menue...\n";
		system("pause>0");

		ShowTransactionsMenue();
	}

public:

	static void ShowTransactionsMenue()
	{
		if (!_CheckRigtAccess(clsUser::enPermissions::pTransactions))
		{
			return;
		}

		system("cls");
		_DrawScreenHeader("\t   Transactions Screen");

		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t\t  Transactions Menue\n";
		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t[1] Deposit.\n";
		cout << setw(37) << left << "" << "\t[2] Withdraw.\n";
		cout << setw(37) << left << "" << "\t[3] Total Balances.\n";
		cout << setw(37) << left << "" << "\t[4] Transfer.\n";
		cout << setw(37) << left << "" << "\t[5] Transfer Log.\n";
		cout << setw(37) << left << "" << "\t[6] Main Menue.\n";
		cout << setw(37) << left << "" << "===========================================\n";


		_PerformTransactiosMenue(enTransactionMenue(ReadChooseUser()));
	}

};

