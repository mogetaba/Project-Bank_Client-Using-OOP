#pragma once
#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"

class clsDeleteUserScreen : protected clsScreen
{
private :

	static void _PrintUser(clsUser User)
	{
		cout << "\nUser Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << User.FirstName;
		cout << "\nLastName    : " << User.LastName;
		cout << "\nFull Name   : " << User.getFullName();
		cout << "\nEmail       : " << User.Email;
		cout << "\nPhone       : " << User.Phone;
		cout << "\nUser Name   : " << User.user_name;
		cout << "\nPassword    : " << User.password;
		cout << "\nPermissions : " << User.permissions;
		cout << "\n___________________\n";

	}

public :

	static void ShowDeleteUserScreen()
	{

		_DrawScreenHeader("\t   Delete User Screen");
		string UserName = "";

		cout << "Please Enter User Name : ";
		UserName = clsInputValidate::ReadString();

		while (!clsUser::IsUserExits(UserName))
		{
			cout << "This User Name is not found , enter another User Name : ";
			UserName = clsInputValidate::ReadString();
		}

		clsUser User = clsUser::Find(UserName); 
		_PrintUser(User);

		cout << "\nAre you sure want to delete this User ? [y/n]";
		char Answer = clsInputValidate::ReadCharcter();

		if (Answer == 'y' || Answer == 'Y')
		{
			if (User.Delete())
			{
				cout << "\nDeleted User done successfully !\n";
				_PrintUser(User);
			}
			else
			{
				cout << "\nError , faild delete user !\n";
			}
		}
		else {

			cout << "\nOperation Canceled :-) \n";

		}


	}


};

