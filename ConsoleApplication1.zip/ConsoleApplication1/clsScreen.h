#pragma once

#include <iostream>
using namespace std;

#include "clsUser.h"
#include "Global.h"

#include "clsDate.h"

class clsScreen
{

protected:

	static void _DrawScreenHeader( string Title , string SubTitle = "")
	{
		cout << "\n\t\t\t\t\t___________________________________________________________\n";

		cout << "\n\n\t\t\t\t\t" << Title;

		if (SubTitle != "")
		{
			cout << "\n\t\t\t\t\t" << SubTitle;
		}

		cout << "\n\t\t\t\t\t___________________________________________________________\n";

		cout << "\n\t\t\t\t\tUser : " << CurrentUser.user_name;
		cout << "\n\t\t\t\t\tDate : " << clsDate::DateToString(clsDate::GetSystemDate())
			<< "\n\n";
	}

	static bool _CheckRigtAccess(clsUser::enPermissions Permission)
	{
		if (!CurrentUser.CheckAccessPermissons(Permission))
		{
			cout << "\n\t\t\t\t\t___________________________________________________________\n";
			cout << "\n\n\t\t\t\t\t  Access Denied! Contact your Admin.";
			cout << "\n\t\t\t\t\t___________________________________________________________\n";
			
			return false;

		}

		return true;
	}
};

