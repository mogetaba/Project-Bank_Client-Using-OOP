#pragma once

#include <iostream>
using namespace std;


#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsBankClient.h"

class clsDepositScreen : protected clsScreen
{
private :

	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}

	static string _ReadAccountNumber()
	{
		return clsInputValidate::ReadString();
	}

public :

	static void ShowDepositScreen()
	{
		_DrawScreenHeader("\t Deposit Screen");

		cout << "Enter Account Number : ";
		string AccountNumber = _ReadAccountNumber();
	
		while (!clsBankClient::IsClientExits(AccountNumber))
		{
			cout << "Client with [" << AccountNumber << "] does not founs , please enter another account number : ";
			AccountNumber = _ReadAccountNumber();
		}

		clsBankClient Client = clsBankClient::Find(AccountNumber);
		_PrintClient(Client);

		cout << "\nPlease Enter Number to Deposit : ";
		int Amount = clsInputValidate::ReadIntNumber();

		cout << "\nAre You sure to perform this transactions ? [y/n]";

		char Answer = 'n';
		cin >> Answer;

		if (Answer == 'y' || Answer == 'Y')
		{
			Client.Deposit(Amount);
			cout << "\nDone Depoist [" << Amount << "] Successfully :-)\n";
			cout << "\nBalance Now : " << Client.Balance << endl;
		}
		else
		{
			cout << "\nOperation is Cancelled \n";
		}
	}

};

