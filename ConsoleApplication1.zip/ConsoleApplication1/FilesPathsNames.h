#pragma once

#include <iostream>
using namespace std;

inline string UserFilePathName = "Users.txt";
inline string ClientFilePathName = "Clients.txt";