#pragma once

#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"
#include "Global.h"

#include "clsMainScreen.h"


class clsLoginScreen : protected clsScreen
{
private :

	static bool _Login()
	{
		bool LoginFaild = false;
		string UserName = "", Password = "";
		short CountLoginFaild = 0;

		do
		{
			
			cout << "\nEnter User Name : ";
			UserName = clsInputValidate::ReadString();

			cout << "\nEnter Password : ";
			Password = clsInputValidate::ReadString();

			CurrentUser = clsUser::Find(UserName, Password);
			LoginFaild = CurrentUser.IsEmpty();

			if (LoginFaild)
			{
				CountLoginFaild++;
				cout << "\nInvalid UserName/Passwird !\n";
				cout << "You have " << (3-CountLoginFaild) << " trails login\n\n";
			}

			if (CountLoginFaild == 3)
			{
				cout << "\nSystem Locked after 3 trailes login faild\n";
				return false;
			}
		} while (LoginFaild);

		CurrentUser.RegisterLogIn();
		clsMainScreen::ShowMainMenue();
	}

public :

	static bool ShowLoginScreen()
	{
		system("cls");
		_DrawScreenHeader("\t  Login Screen");
		return _Login();
	}

};

