#pragma once

#include <iostream>
using namespace std;

#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsBankClient.h"


#include "clsUser.h"

class clsAddNewClientScreen : protected clsScreen
{
private:

	static void _ReadInfoClient(clsBankClient& NewClient)
	{
		cout << "Enter First Name  : ";
		NewClient.FirstName = clsInputValidate::ReadString();

		cout << "Enter Last Name : ";
		NewClient.LastName = clsInputValidate::ReadString();

		cout << "Enter Email : ";
		NewClient.Email = clsInputValidate::ReadString();

		cout << "Enter Phone : ";
		NewClient.Phone = clsInputValidate::ReadString();

		cout << "Enter Pin Code : ";
		NewClient.PinCode = clsInputValidate::ReadString();

		cout << "Enter Balance : ";
		NewClient.Balance = clsInputValidate::ReadIntNumber();
	}


	static void _PrintClient(clsBankClient Client)
	{
		cout << "\nClient Card:";
		cout << "\n___________________";
		cout << "\nFirstName   : " << Client.FirstName;
		cout << "\nLastName    : " << Client.LastName;
		cout << "\nFull Name   : " << Client.getFullName();
		cout << "\nEmail       : " << Client.Email;
		cout << "\nPhone       : " << Client.Phone;
		cout << "\nAcc. Number : " << Client.getAccountNumber();
		cout << "\nPassword    : " << Client.PinCode;
		cout << "\nBalance     : " << Client.getBalance();
		cout << "\n___________________\n";

	}


public:

	static void ShowAddNewClientScreen()
	{

		if (!_CheckRigtAccess(clsUser::enPermissions::pAddNewClient))
		{
			return;
		}

		_DrawScreenHeader("\t  Add New Client Screen");

		cout << "Enter Account Number : ";
		string AccountNumber = clsInputValidate::ReadString();

		while (clsBankClient::IsClientExits(AccountNumber))
		{
			cout << "Error this Acc. number is found  , enter another Acc. number : ";
			AccountNumber = clsInputValidate::ReadString();
		}


		clsBankClient NewClient = clsBankClient::getAddNewClientObject(AccountNumber);
		_ReadInfoClient(NewClient);

		clsBankClient::enSaveResult SaveResult = NewClient.Save();

		switch (SaveResult)
		{
		case clsBankClient::enSaveResult::svFaildAccountNumberExits:
		{
			cout << "Err! Because this account number is found in file form before :-< \n";
			break;
		}

		case clsBankClient::enSaveResult::svFaildEmptyClient:
		{
			cout << "Err! Because this account empty :-< \n";
			break;
		}

		case clsBankClient::enSaveResult::svSuccessded:
		{
			cout << "\nAccount Added successfully :-> \n\n";
			_PrintClient(NewClient);
			break;
		}
		}
	}

};

