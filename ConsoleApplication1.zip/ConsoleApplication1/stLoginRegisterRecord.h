#pragma once
#include <iostream>
using namespace std;

struct stLoginRegisterRecord {
	string Date_Time;
	string UserName;
	string Password;
	int Permissions;
};