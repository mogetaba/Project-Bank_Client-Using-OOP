#pragma once

#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

#include "clsBankClient.h"
#include "clsScreen.h"
#include "clsUtil.h"

class clsTotalBalancesScreen : protected clsScreen
{
private :

    static void _PrintClientRecordBalanceLine(clsBankClient Client)
    {
        cout << setw(25) << left << "" << "| " << setw(15) << left << Client.getAccountNumber();
        cout << "| " << setw(40) << left << Client.getFullName();
        cout << "| " << setw(12) << left << Client.Balance;
    }

public :

    static void ShowTotalBalancesScreen()
    {
        vector <clsBankClient> vClients = clsBankClient::GetListClient();

        string Title = "\t   Total Balances Screen";
        string SubTitle = "\t\t\t(" + to_string(vClients.size()) + ") Clients(s).";

        _DrawScreenHeader(Title , SubTitle);
    
        cout << setw(25) << left << "" << "\n\t\t_______________________________________________________";
        cout << "__________________________\n" << endl;

        cout << setw(25) << left << "" << "| " << left << setw(15) << "Accout Number";
        cout << "| " << left << setw(40) << "Client Name";
        cout << "| " << left << setw(12) << "Balance";
        cout << setw(25) << left << "" << "\t\t_______________________________________________________";
        cout << "__________________________\n" << endl;

        double TotalBalances = clsBankClient::GetTotalBalances();

        if (vClients.size() == 0)
            cout << "\t\t\t\tNo Clients Available In the System!";
        else

            for (clsBankClient Client : vClients)
            {
                _PrintClientRecordBalanceLine(Client);
                cout << endl;
            }

        cout << setw(25) << left << "" << "\n\t\t_______________________________________________________";
        cout << "__________________________\n" << endl;

        cout << setw(8) << left << "" << "\t\t\t\t     Total Balances = " << TotalBalances << endl;
        cout << setw(8) << left << "" << "\t\t\t\t     ( " << clsUtil::NumberToText(TotalBalances) << " )" << endl;
    
    }

};

