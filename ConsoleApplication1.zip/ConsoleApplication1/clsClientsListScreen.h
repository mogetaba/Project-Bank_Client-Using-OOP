#pragma once

#include <iostream>
#include <vector>

#include "clsBankClient.h"
#include "clsScreen.h"

#include "clsUser.h"

using namespace std; 

class clsClientsList : protected clsScreen
{
private:

    static void PrintClientRecordLine(clsBankClient Client)
    {

        cout << setw(8) << left << "" << "| " << setw(15) << left << Client.getAccountNumber();
        cout << "| " << setw(20) << left << Client.getFullName();
        cout << "| " << setw(12) << left << Client.getPhone();
        cout << "| " << setw(20) << left << Client.getEmail();
        cout << "| " << setw(10) << left << Client.getPinCode();
        cout << "| " << setw(12) << left << Client.getBalance();

    }

public:

	static void ShowListClients()
	{
        if (!_CheckRigtAccess(clsUser::enPermissions::pListClients))
        {
            return;
        }

		vector <clsBankClient> vClients = clsBankClient::GetListClient();

		string Title = "\t  Client List Screen";
		string SubTitle = "\t   (" + to_string(vClients.size()) + ") Clients(s).";

		_DrawScreenHeader(Title , SubTitle);

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;

        cout << setw(8) << left << "" << "| " << left << setw(15) << "Accout Number";
        cout << "| " << left << setw(20) << "Client Name";
        cout << "| " << left << setw(12) << "Phone";
        cout << "| " << left << setw(20) << "Email";
        cout << "| " << left << setw(10) << "Pin Code";
        cout << "| " << left << setw(12) << "Balance";
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;

        if (vClients.size() == 0)
            cout << "\t\t\t\tNo Clients Available In the System!";
        else

            for (clsBankClient Client : vClients)
            {

                PrintClientRecordLine(Client);
                cout << endl;
            }

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;
	}
};

