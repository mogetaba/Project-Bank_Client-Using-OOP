#pragma once

#include<iostream>
#include<string>
#include<vector>
#include<fstream>

using namespace std;


#include "clsPerson.h"
#include "clsString.h"
#include "clsDataAccess.h"

#include "FilesPathsNames.h"


class clsBankClient : public clsPerson , protected clsDataAccess
{
public:

    struct stTransferRegisteredRecord {
        string DateTime;
        string SourceAccountNumber;
        string DestintionAccountNumber;
        string srcBalanceAfter;
        string destBalanceAfter;
        float Amount;
        string UserName;
    };

    enum enMode { EmptyMode = 0, UpdateMode = 1, AddNewMode = 2 };

private:

    string _AccountNumber;
    string _PinCode;
    double _AccountBalance;
    bool _MarkedForDeleted = false;

    enMode _Mode;



    string _PrepareTransferRecord(clsBankClient DestinitialClient, float Amount , string UserName, string Seperator = "#//#")
    {
        string TransferRecord = "";

        TransferRecord += clsDate::GetSystemDateTimeByString() + Seperator;
        TransferRecord += _AccountNumber + Seperator;
        TransferRecord += DestinitialClient._AccountNumber + Seperator;
        TransferRecord += to_string(Amount) + Seperator;
        TransferRecord += to_string(_AccountBalance) + Seperator;
        TransferRecord += to_string(DestinitialClient._AccountBalance) + Seperator;
        TransferRecord += UserName;

        return TransferRecord;
    }

    static stTransferRegisteredRecord _ConvertLineTransferToRecord(string Line, string Seperator = "#//#")
    {
        vector <string> S1 = clsString::Split(Line, Seperator);
        stTransferRegisteredRecord stDataLine;

        stDataLine.DateTime = S1[0];
        stDataLine.SourceAccountNumber = S1[1];
        stDataLine.DestintionAccountNumber = S1[2];
        stDataLine.Amount = stof(S1[3]);
        stDataLine.srcBalanceAfter = S1[4];
        stDataLine.destBalanceAfter = S1[5];
        stDataLine.UserName = S1[6];

        return stDataLine;
    }

    void _RegisterTransferOperation(clsBankClient DestintialClient, float Amount, string UserName, string Seperator = "#//#")
    {
        string Line = _PrepareTransferRecord(DestintialClient, Amount, UserName, Seperator);

        fstream MyFile;
        MyFile.open("TransferRegister.txt", ios::out | ios::app);

        if (MyFile.is_open())
        {
            MyFile << Line << endl;
            MyFile.close();
        }
    }


    void _Update()
    {
        vector <clsBankClient> _vClient = _LoadDataFromFile(ClientFilePathName , true);

        for (clsBankClient& C : _vClient)
        {
            if (C.getAccountNumber() == getAccountNumber())
            {
                C = *this;
                break;
            }

        }


        _SaveClientDataToFile(_vClient , ClientFilePathName);
    }


    void _AddNew()
    {
        string Line = _ConvertClientObjectToLine(*this);
        clsBankClient::_AddClientDataToFile(Line , ClientFilePathName);
    }


    static clsBankClient _getEmptyClient()
    {
        return clsBankClient(enMode::EmptyMode, "", "", "", "", "", "", 0);
    }

public:

    

    clsBankClient()
        : clsPerson("", "", "", "")
    {

    }

    clsBankClient(enMode Mode, string FirstName, string LastName, string Email
        , string Phone, string AccountNumber, string PinCode, double Balance)
        : clsPerson(FirstName, LastName, Email, Phone)
    {
        _Mode = Mode;

        _AccountNumber = AccountNumber;
        _PinCode = PinCode;
        _AccountBalance = Balance;
    }


    bool IsEmpty()
    {
        return (_Mode == enMode::EmptyMode);
    }


    // Account Number
    string getAccountNumber()
    {
        return _AccountNumber;
    }


    // Pin Code
    void setPinCode(string PinCode)
    {
        _PinCode = PinCode;
    }

    string getPinCode()
    {
        return _PinCode;
    }

    _declspec(property(get = getPinCode, put = setPinCode)) string PinCode;


    // Balance
    void setBalance(double Balance)
    {
        _AccountBalance = Balance;
    }

    double getBalance()
    {
        return _AccountBalance;
    }

    __declspec(property(get = getBalance, put = setBalance)) double Balance;

    // MarkedForDeleted
    bool getMarkedForDeleted()
    {
        return _MarkedForDeleted;
    }

    // Mode
    enMode getMode()
    {
        return _Mode;
    }

    static clsBankClient Find(string AccountNumber)
    {

        vector <clsBankClient> vClient = _LoadDataFromFile(ClientFilePathName , true);

        for (clsBankClient& C : vClient)
        {
            if (C.getAccountNumber() == AccountNumber)
                return C;
        }

        return _getEmptyClient();
    }


    static clsBankClient Find(string AccountNumber, string PinCode)
    {
        vector <clsBankClient> vClient = _LoadDataFromFile(ClientFilePathName, true);

        for (clsBankClient& C : vClient)
        {
            if (C.getAccountNumber() == AccountNumber)
            {
                if(C.getPinCode() == PinCode)
                    return C;
            }
        }

        return _getEmptyClient();
    }

    static bool IsClientExits(string AccountNumber)
    {
        clsBankClient Client = clsBankClient::Find(AccountNumber);
        return (!Client.IsEmpty());
    }


    bool Delete()
    {
        vector <clsBankClient> _vClient = _LoadDataFromFile(ClientFilePathName , true);

        for (clsBankClient& C : _vClient)
        {
            if (C.getAccountNumber() == getAccountNumber())
            {
                C._MarkedForDeleted = true;
                _SaveClientDataToFile(_vClient , ClientFilePathName);
                *this = _getEmptyClient();
                return true;
            }
        }

        return false;
    }

    static vector <clsBankClient> GetListClient()
    {
        return _LoadDataFromFile(ClientFilePathName , true);
    }


    void Deposit(double Amount)
    {
        _AccountBalance += Amount;
        Save();
    }

    bool Withdraw(double Amount)
    {
        if (Amount > this->_AccountBalance)
        {
            return false;
        }
        
        _AccountBalance -= Amount;
        Save();
        return true;
    }

    static double GetTotalBalances()
    {
        vector <clsBankClient> vClient = _LoadDataFromFile(ClientFilePathName , true);
        double TotalBalances = 0;


        for (clsBankClient& C : vClient)
        {
            TotalBalances += C.getBalance();
        }

        return TotalBalances;
    }

    bool Transfer( clsBankClient& DestintialClient , float Amount , string UserName )
    {
       

        if (Amount > Balance)
        {
            return false;
        }
        
        if (_AccountNumber == DestintialClient._AccountNumber)
        {
            return false;
        }

        Withdraw(Amount);
        DestintialClient.Deposit(Amount);
        _RegisterTransferOperation(DestintialClient, Amount , UserName);
        return true;

    }

    static clsBankClient getAddNewClientObject(string AccountNumber)
    {
        return clsBankClient(enMode::AddNewMode, "", "", "", "", AccountNumber, "", 0);
    }

    static vector <stTransferRegisteredRecord> GetListTransferLogRecord()
    {
        vector <stTransferRegisteredRecord> vTransferLogRecord;

        fstream MyFile;
        MyFile.open("TransferRegister.txt" , ios::in);

        if (MyFile.is_open())
        {
            string Line;
            stTransferRegisteredRecord stDataLine;

            while (getline(MyFile, Line))
            {
                stDataLine = _ConvertLineTransferToRecord(Line);
                vTransferLogRecord.push_back(stDataLine);
            }

            MyFile.close();
        }

        return vTransferLogRecord;
    }

    enum enSaveResult { svFaildEmptyClient = 0, svSuccessded = 1 , svFaildAccountNumberExits = 2 };

    enSaveResult Save()
    {
        switch (_Mode)
        {
        case enMode::EmptyMode:
        {
            return enSaveResult::svFaildEmptyClient;
        }

        case enMode::UpdateMode:
        {
            _Update();
            return enSaveResult::svSuccessded;
        }

        case enMode::AddNewMode : 
        {
            if (IsClientExits(_AccountNumber))
            {
                return enSaveResult::svFaildAccountNumberExits;
            }

            _AddNew();
            _Mode = enMode::UpdateMode;
            return enSaveResult::svSuccessded;
        }

        default:

            return enSaveResult::svFaildEmptyClient;
        }
    }
};

